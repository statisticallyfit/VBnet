﻿Module Module1
    ' This loop will print numbers 9 to 0 in descending order
    Sub Main()
        ' Initialize variable
        Dim number As Integer = 9
        Do
            'Print the number to see it first
            System.Console.WriteLine(number)
            'Now decrement it by 1
            number = number - 1

            ' If the number is greater than or equal to 0, exit loop. After being decremented to -1, 
            ' index is checked against condition and will not be printed.     
        Loop While (number >= 0)

        System.Console.WriteLine("The loop is over")

        ' This pauses program to see output
        System.Console.ReadKey()

    End Sub

End Module
